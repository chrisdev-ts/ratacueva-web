import Home from "./landing/home/page";
export default Home;
