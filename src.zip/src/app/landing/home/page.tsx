import HeroSection from "@/components/landing/home/hero-section";
import ProductSection from "@/components/landing/home/product-section";
import FeaturedBanner from "@/components/landing/home/featured-banner";
import CommunitySection from "@/components/landing/home/community-section";
import FaqSection from "@/components/landing/home/faq-section";
import Footer from "@/components/landing/home/footer";
import Header from "@/components/landing/home/header";

export default function Home() {
  return (
    <div className="w-full bg-zinc-900 flex flex-col justify-start items-start overflow-hidden">
      <Header />

      <HeroSection />

      <div className="max-w-[1440px] mx-auto px-10 w-full">
        <ProductSection
          title="Ofertas y nuevos lanzamientos"
          products={sampleProducts}
        />

        <FeaturedBanner />

        <ProductSection
          title="Videojuegos"
          products={sampleProducts}
          showViewAll={true}
        />

        <ProductSection
          title="Componentes"
          products={sampleProducts}
          showViewAll={true}
        />

        <ProductSection
          title="Computadoras"
          products={sampleProducts}
          showViewAll={true}
        />

        <ProductSection
          title="Consolas"
          products={sampleProducts}
          showViewAll={true}
        />

        <ProductSection
          title="Workstations"
          products={sampleProducts}
          showViewAll={true}
        />

        <ProductSection
          title="Accesorios"
          products={sampleProducts}
          showViewAll={true}
        />

        <CommunitySection />

        <FaqSection />
      </div>

      <Footer />
    </div>
  );
}

// Sample data for products
const sampleProducts = [
  {
    id: 1,
    name: 'Monitor Samsung 47"',
    rating: 4.8,
    reviews: 740,
    price: 2449,
    image: "/landing/home/computer.png",
  },
  {
    id: 2,
    name: 'Monitor Samsung 47"',
    rating: 4.8,
    reviews: 740,
    price: 2449,
    image: "/landing/home/computer.png",
  },
  {
    id: 3,
    name: 'Monitor Samsung 47"',
    rating: 4.8,
    reviews: 740,
    price: 2449,
    image: "/landing/home/computer.png",
  },
  {
    id: 4,
    name: 'Monitor Samsung 47"',
    rating: 4.8,
    reviews: 740,
    price: 2449,
    image: "/landing/home/computer.png",
  },
  {
    id: 5,
    name: 'Monitor Samsung 47"',
    rating: 4.8,
    reviews: 740,
    price: 2449,
    image: "/landing/home/computer.png",
  },
]; 