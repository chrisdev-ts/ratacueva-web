export default function Cart() {
  return <div>Recuperar contraseña</div>;
}
