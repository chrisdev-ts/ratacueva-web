export default function OrderHistory() {
  return <div>Recuperar contraseña</div>;
}
