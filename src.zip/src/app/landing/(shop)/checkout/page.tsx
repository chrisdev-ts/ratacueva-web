export default function Checkout() {
  return <div>Recuperar contraseña</div>;
}
