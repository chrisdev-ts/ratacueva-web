export default function Category() {
  return <div>Recuperar contraseña</div>;
}
