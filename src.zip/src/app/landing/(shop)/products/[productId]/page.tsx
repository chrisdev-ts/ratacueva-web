export default function ProductId() {
  return <div>Recuperar contraseña</div>;
}
