"use client"

import { useRef } from "react"
import ProductCard from "./product-card"
import { ChevronLeft, ChevronRight } from "lucide-react"
import Link from "next/link"

interface ProductSectionProps {
  title: string
  products: Array<{
    id: number
    name: string
    rating: number
    reviews: number
    price: number
    image: string
  }>
  showViewAll?: boolean
}

export default function ProductSection({ title, products, showViewAll = false }: ProductSectionProps) {
  const scrollContainerRef = useRef<HTMLDivElement>(null)

  const scrollLeft = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: -300, behavior: "smooth" })
    }
  }

  const scrollRight = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: 300, behavior: "smooth" })
    }
  }

  return (
    <div className="self-stretch px-4 md:px-20 py-9 flex flex-col justify-center items-start gap-9 overflow-hidden">
      <div className="self-stretch flex justify-between items-center">
        <h2 className="text-white text-xl font-bold">{title}</h2>

        {showViewAll && (
          <Link
            href={`/category/${title.toLowerCase().replace(/\s+/g, "-")}`}
            className="h-11 min-h-11 px-4 py-2.5 rounded-[99px] outline outline-1 outline-offset-[-1px] outline-cyan-400 flex justify-center items-center gap-3"
          >
            <span className="text-cyan-400 text-base font-bold">Ver todo</span>
          </Link>
        )}
      </div>

      <div className="self-stretch relative">
        <div
          ref={scrollContainerRef}
          className="flex overflow-x-auto gap-4 md:gap-8 pb-4 scrollbar-hide"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          {products.map((product) => (
            <div key={product.id} className="min-w-[250px] md:min-w-[280px]">
              <ProductCard product={product} />
            </div>
          ))}
        </div>

        <button
          onClick={scrollRight}
          className="w-11 h-11 md:w-14 md:h-14 min-w-11 min-h-11 p-2.5 absolute right-0 top-1/2 -translate-y-1/2 bg-neutral-600 rounded-[99px] flex justify-center items-center gap-3 z-10"
        >
          <ChevronRight className="w-6 h-6 text-white" />
        </button>

        <button
          onClick={scrollLeft}
          className="w-11 h-11 md:w-14 md:h-14 min-w-11 min-h-11 p-2.5 absolute left-0 top-1/2 -translate-y-1/2 bg-neutral-600 rounded-[99px] flex justify-center items-center gap-3 z-10"
        >
          <ChevronLeft className="w-6 h-6 text-white" />
        </button>
      </div>
    </div>
  )
}
