export default function HeroSection() {
  return (
    <div className="self-stretch h-[300px] md:h-[625px] relative bg-zinc-800">{/* Hero content will go here */}</div>
  )
}
