import { Search, ShoppingCart, User, Heart } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function Header() {
  return (
    <header className="self-stretch px-4 md:px-20 py-6 flex justify-start items-center gap-4 md:gap-12">
      <Link href="/" className="flex justify-start items-center gap-[4.97px]">
        <Image
          className="w-9 h-9"
          src="/landing/home/logo.png"
          alt="RataCueva Logo"
          width={36}
          height={36}
        />
        <div className="text-neutral-400 text-3xl font-black font-exo">RataCueva</div>
      </Link>

      <div className="flex-1 min-h-11 px-4 py-2.5 rounded-2xl outline outline-1 outline-offset-[-1px] outline-zinc-300 flex justify-start items-center gap-3">
        <Search className="w-6 h-6 text-zinc-300" />
        <div className="text-zinc-300 text-base font-normal">Buscar productos...</div>
      </div>

      <div className="hidden md:flex justify-start items-center gap-6">
        <Link
          href="/build-pc"
          className="h-11 min-h-11 px-4 py-2.5 bg-pink-600 rounded-[99px] flex justify-center items-center gap-3"
        >
          <ShoppingCart className="w-6 h-6 text-white" />
          <span className="text-white text-base font-bold">Arma tu pc</span>
        </Link>

        <div className="flex justify-start items-center gap-4">
          <button className="h-11 min-h-11 p-2.5 bg-pink-600 rounded-[99px] flex justify-center items-center">
            <Heart className="w-6 h-6 text-white" />
          </button>
          <button className="h-11 min-h-11 p-2.5 bg-pink-600 rounded-[99px] flex justify-center items-center">
            <ShoppingCart className="w-6 h-6 text-white" />
          </button>
          <button className="h-11 min-h-11 p-2.5 bg-pink-600 rounded-[99px] flex justify-center items-center">
            <User className="w-6 h-6 text-white" />
          </button>
        </div>
      </div>
    </header>
  )
}
