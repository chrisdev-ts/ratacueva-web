import Image from "next/image"

interface ProductCardProps {
  product: {
    id: number
    name: string
    rating: number
    reviews: number
    price: number
    image: string
  }
}

export default function ProductCard({ product }: ProductCardProps) {
  return (
    <div className="flex-1 bg-zinc-800 rounded-lg flex flex-col justify-center items-center overflow-hidden">
      <div className="self-stretch h-56 p-4 flex flex-col justify-center items-center gap-2.5">
        <Image
          className="w-48 flex-1 object-contain"
          src={product.image || "/placeholder.svg"}
          alt={product.name}
          width={189}
          height={189}
        />
      </div>
      <div className="self-stretch h-0 outline outline-1 outline-offset-[-0.50px] outline-white"></div>
      <div className="self-stretch p-6 flex flex-col justify-start items-start gap-2">
        <h6 className="self-stretch text-white  text-xl font-semibold">{product.name}</h6>
        <div className="self-stretch flex justify-start items-center gap-2">
          <div className="text-center text-white text-base font-normal">{product.rating}</div>
          <div className="text-center text-white text-base font-normal">({product.reviews})</div>
        </div>
        <div className="self-stretch text-white text-xl font-semibold">${product.price}</div>
      </div>
    </div>
  )
}
