export default function FeaturedBanner() {
  return (
    <div className="self-stretch px-4 md:px-20 py-9 flex flex-col md:flex-row justify-start items-center gap-9 overflow-hidden">
      <div className="flex-1 self-stretch h-[300px] md:h-[472px] relative bg-zinc-800 rounded-lg" />

      <div className="flex-1 h-auto md:h-[472px] grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-9">
        <div className="h-[200px] md:h-full bg-zinc-800 rounded-lg" />
        <div className="h-[200px] md:h-full bg-zinc-800 rounded-lg" />
        <div className="h-[200px] md:h-full bg-zinc-800 rounded-lg" />
        <div className="h-[200px] md:h-full bg-zinc-800 rounded-lg" />
      </div>
    </div>
  )
}
