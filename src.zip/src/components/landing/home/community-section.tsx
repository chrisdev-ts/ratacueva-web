import { Facebook, Instagram, Twitter, Youtube } from "lucide-react"
import Link from "next/link"

export default function CommunitySection() {
  return (
    <div className="self-stretch px-4 md:px-20 py-9 flex flex-col justify-center items-start gap-9 overflow-hidden">
      <div className="self-stretch flex-1 flex flex-col md:flex-row justify-start items-start gap-8">
        <div className="w-full md:w-[640px] self-stretch px-4 md:px-12 flex flex-col justify-center items-start gap-6 overflow-hidden">
          <h2 className="self-stretch text-white text-2xl md:text-3xl font-bold">
            ¿Qué opina la comunidad de RataCueva?
          </h2>

          <p className="self-stretch text-white text-base md:text-xl font-normal">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
            dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex
            ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat
            nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit
            anim id est laborum.
          </p>

          <div className="self-stretch flex flex-wrap justify-start items-start gap-4 md:gap-6">
            <Link
              href="#"
              className="h-11 min-h-11 px-4 py-2.5 bg-pink-600 rounded-[99px] flex justify-center items-center gap-3"
            >
              <Facebook className="w-6 h-6 text-white" />
              <span className="text-white text-base font-bold">Facebook</span>
            </Link>

            <Link
              href="#"
              className="h-11 min-h-11 px-4 py-2.5 bg-pink-600 rounded-[99px] flex justify-center items-center gap-3"
            >
              <Instagram className="w-6 h-6 text-white" />
              <span className="text-white text-base font-bold">Instagram</span>
            </Link>

            <Link
              href="#"
              className="h-11 min-h-11 px-4 py-2.5 bg-pink-600 rounded-[99px] flex justify-center items-center gap-3"
            >
              <Twitter className="w-6 h-6 text-white" />
              <span className="text-white text-base font-bold">X</span>
            </Link>

            <Link
              href="#"
              className="h-11 min-h-11 px-4 py-2.5 bg-pink-600 rounded-[99px] flex justify-center items-center gap-3"
            >
              <Youtube className="w-6 h-6 text-white" />
              <span className="text-white text-base font-bold">YouTube</span>
            </Link>
          </div>
        </div>

        <div className="flex-1 self-stretch grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-9">
          <div className="flex flex-col gap-4 md:gap-9">
            <div className="h-56 bg-zinc-800 rounded-lg" />
            <div className="h-56 bg-zinc-800 rounded-lg" />
          </div>

          <div className="flex flex-col gap-4 md:gap-9">
            <div className="h-56 bg-zinc-800 rounded-lg" />
            <div className="h-56 bg-zinc-800 rounded-lg" />
            <div className="h-56 bg-zinc-800 rounded-lg hidden md:block" />
          </div>
        </div>
      </div>
    </div>
  )
}
