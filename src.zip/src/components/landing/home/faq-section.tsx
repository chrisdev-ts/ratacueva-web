"use client"

import { useState } from "react"
import { ChevronDown, ChevronUp } from "lucide-react"

const faqItems = [
  {
    question: "¿Qué es RataCueva?",
    answer: "RataCueva es una tienda especializada en productos de tecnología y gaming.",
  },
  {
    question: "¿Cómo puedo realizar un pedido?",
    answer: "Puedes realizar un pedido a través de nuestra página web o visitando nuestra tienda física.",
  },
  {
    question: "¿Cuáles son los métodos de pago disponibles?",
    answer: "Aceptamos tarjetas de crédito/débito, transferencias bancarias y efectivo en tienda.",
  },
  {
    question: "¿Cuánto tiempo tarda en llegar mi pedido?",
    answer: "El tiempo de entrega depende de tu ubicación, generalmente entre 3-5 días hábiles.",
  },
  {
    question: "¿Tienen garantía los productos?",
    answer: "Sí, todos nuestros productos cuentan con garantía del fabricante.",
  },
  {
    question: "¿Puedo devolver un producto?",
    answer: "Sí, tienes hasta 14 días para devolver un producto en su empaque original.",
  },
  { question: "¿Hacen envíos internacionales?", answer: "Actualmente solo realizamos envíos dentro del país." },
  {
    question: "¿Ofrecen servicio técnico?",
    answer: "Sí, contamos con servicio técnico especializado para reparación y mantenimiento.",
  },
  { question: "¿Tienen tienda física?", answer: "Sí, contamos con tiendas físicas en las principales ciudades." },
  {
    question: "¿Cómo puedo contactar al soporte?",
    answer: "Puedes contactarnos por correo a support@ratacueva.com o por teléfono.",
  },
  {
    question: "¿Tienen programa de lealtad?",
    answer: "Sí, contamos con un programa de puntos por compras que puedes canjear por descuentos.",
  },
  { question: "¿Ofrecen factura?", answer: "Sí, emitimos factura electrónica para todas las compras." },
]

const paymentMethods = ["Visa", "Mastercard", "American Express", "PayPal", "Transferencia bancaria", "Efectivo"]
const cashDepositLocations = ["Banco 1", "Banco 2", "Banco 3"]
const shippingCompanies = ["DHL", "FedEx", "UPS", "Correos", "Mensajería local"]

export default function FaqSection() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null)

  const toggleFaq = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index)
  }

  return (
    <div className="self-stretch px-4 md:px-20 py-9 flex flex-col md:flex-row justify-center items-start gap-9 overflow-hidden">
      <div className="w-full md:w-[640px] self-stretch px-4 md:px-12 flex flex-col justify-center items-start gap-9 overflow-hidden">
        <div className="self-stretch flex flex-col justify-start items-start gap-6">
          <h2 className="self-stretch text-white text-2xl md:text-3xl font-bold">Preguntas frecuentes</h2>
          <p className="self-stretch text-white text-base md:text-xl font-normal">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
            dolore magna aliqua.
          </p>
        </div>

        <div className="self-stretch h-0 outline outline-1 outline-offset-[-0.50px] outline-white"></div>

        <div className="self-stretch flex flex-col justify-start items-start gap-6">
          <h2 className="self-stretch text-white text-2xl md:text-3xl font-bold">Recuerda que puedes pagar con</h2>
          <p className="self-stretch text-white text-base md:text-xl font-normal">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
          </p>
          <div className="self-stretch flex flex-wrap justify-start items-start gap-4 md:gap-6">
            {paymentMethods.map((method, index) => (
              <div
                key={index}
                className="w-36 h-11 min-h-11 px-4 py-2.5 bg-zinc-800 rounded-[99px] flex items-center justify-center text-white"
              >
                {method}
              </div>
            ))}
          </div>
        </div>

        <div className="self-stretch flex flex-col justify-start items-start gap-6">
          <h2 className="self-stretch text-white text-2xl md:text-3xl font-bold">
            Puedes realizar depósitos en efectivo en
          </h2>
          <div className="self-stretch flex flex-wrap justify-start items-start gap-4 md:gap-6">
            {cashDepositLocations.map((location, index) => (
              <div
                key={index}
                className="w-36 h-11 min-h-11 px-4 py-2.5 bg-zinc-800 rounded-[99px] flex items-center justify-center text-white"
              >
                {location}
              </div>
            ))}
          </div>
        </div>

        <div className="self-stretch h-0 outline outline-1 outline-offset-[-0.50px] outline-white"></div>

        <div className="self-stretch flex flex-col justify-start items-start gap-6">
          <h2 className="self-stretch text-white text-2xl md:text-3xl font-bold">Tu paquete en las mejores manos</h2>
          <p className="self-stretch text-white text-base md:text-xl font-normal">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
          </p>
          <div className="self-stretch flex flex-wrap justify-start items-start gap-4 md:gap-6">
            {shippingCompanies.map((company, index) => (
              <div
                key={index}
                className="w-36 h-11 min-h-11 px-4 py-2.5 bg-zinc-800 rounded-[99px] flex items-center justify-center text-white"
              >
                {company}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="flex-1 self-stretch flex flex-col justify-center items-start gap-4 overflow-hidden">
        {faqItems.map((item, index) => (
          <div
            key={index}
            className="self-stretch px-6 py-4 bg-zinc-800 rounded-lg overflow-hidden cursor-pointer"
            onClick={() => toggleFaq(index)}
          >
            <div className="flex justify-between items-center">
              <div className="text-white text-base font-normal">{item.question}</div>
              {activeIndex === index ? (
                <ChevronUp className="w-5 h-5 text-white" />
              ) : (
                <ChevronDown className="w-5 h-5 text-white" />
              )}
            </div>
            {activeIndex === index && <div className="mt-2 text-zinc-300 text-sm">{item.answer}</div>}
          </div>
        ))}
      </div>
    </div>
  )
}
