export { PageLayout } from "@/components/templates/PageLayout";
export { ContentLayout } from "@/components/templates/ContentLayout";
