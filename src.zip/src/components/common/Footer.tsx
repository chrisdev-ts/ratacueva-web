import Link from "next/link"
import Image from "next/image"
import { Facebook, Instagram, Twitter, Youtube } from "lucide-react"

export default function Footer() {
  return (
    <footer className="self-stretch px-4 md:px-20 py-9 flex flex-col justify-center items-start gap-9 overflow-hidden">
      <div className="self-stretch grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
        <div className="flex flex-col justify-start items-start gap-6 overflow-hidden">
          <div className="self-stretch flex flex-col justify-start items-start gap-4">
            <Link href="/" className="flex justify-start items-center gap-[4.97px]">
              <Image
                className="w-9 h-9"
                src="/placeholder.svg?height=36&width=36"
                alt="RataCueva Logo"
                width={36}
                height={36}
              />
              <div className="text-neutral-400 text-3xl font-black font-exo">RataCueva</div>
            </Link>

            <p className="self-stretch text-white text-base md:text-xl font-normal">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
              dolore magna aliqua.
            </p>
          </div>

          <div className="flex flex-col justify-start items-start gap-4">
            <h3 className="self-stretch text-white text-xl font-bold">Síguenos en nuestras redes sociales</h3>

            <div className="self-stretch flex flex-wrap justify-start items-start gap-4">
              <Link href="#" className="w-11 h-11 min-h-11 bg-pink-600 rounded-[99px] flex justify-center items-center">
                <Facebook className="w-6 h-6 text-white" />
              </Link>

              <Link href="#" className="w-11 h-11 min-h-11 bg-pink-600 rounded-[99px] flex justify-center items-center">
                <Instagram className="w-6 h-6 text-white" />
              </Link>

              <Link href="#" className="w-11 h-11 min-h-11 bg-pink-600 rounded-[99px] flex justify-center items-center">
                <Twitter className="w-6 h-6 text-white" />
              </Link>

              <Link href="#" className="w-11 h-11 min-h-11 bg-pink-600 rounded-[99px] flex justify-center items-center">
                <Youtube className="w-6 h-6 text-white" />
              </Link>
            </div>
          </div>

          <div className="text-white text-base font-normal">© 2025 RataCueva. Todos los derechos reservados.</div>
        </div>

        <div className="flex flex-col justify-start items-start overflow-hidden">
          <div className="self-stretch flex flex-col justify-start items-start gap-4">
            <h3 className="self-stretch text-white text-xl font-bold">Secciones</h3>

            <div className="self-stretch flex flex-col justify-start items-start gap-2">
              {[
                "Inicio",
                "Ofertas y nuevos lanzamientos",
                "Videojuegos",
                "Componentes",
                "Computadoras",
                "Consolas",
                "Workstations",
                "Accesorios",
                "Comentarios",
                "Preguntas frecuentes",
              ].map((section, index) => (
                <Link
                  key={index}
                  href="#"
                  className="self-stretch text-white text-base md:text-xl font-normal hover:text-cyan-400 transition-colors"
                >
                  {section}
                </Link>
              ))}
            </div>
          </div>
        </div>

        <div className="flex flex-col justify-start items-start overflow-hidden">
          <div className="self-stretch flex flex-col justify-start items-start gap-4">
            <h3 className="self-stretch text-white text-xl font-bold">Soporte</h3>

            <div className="self-stretch flex flex-col justify-start items-start gap-2">
              {[
                "support@ratacueva.com",
                "pedidos@ratacueva.com",
                "Reparación de computadoras",
                "Mantenimiento de computadoras",
                "Mantenimiento y reaparación de laptops",
              ].map((item, index) => (
                <Link
                  key={index}
                  href="#"
                  className="self-stretch text-white text-base md:text-xl font-normal hover:text-cyan-400 transition-colors"
                >
                  {item}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
